const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
    sender: {type: String, required: true},
    recipient: {type: String, required: true},
    content: {type: String, required: true},
    timsestamp: {type: Date, default: Date.now}
});

module.exports = mongoose.model('Message', messageSchema);

//w